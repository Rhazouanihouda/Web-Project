const livreTemplate = ({ img, titre, categorie, codeProduit, auteur, prix, rabais, description, niveauScolaire }) => {

    return `
    <div class="h_card-parent">
    <div class="h_card">
    <img class="h_card-img-top" src="${img}" alt="Card image" style="height: 6cm; width: 5 cm;">
    <div class=" h_card-body ">
        <h4 class="title">${titre}</h4>
        <ul>
            <li>
                <a id="categorie">${categorie}</a>
            </li>
            <li>
                <a id="codeProduit patern="^[A-Z]{4}[0-9]{8}[A-Z]{2}$">${codeProduit}</a>
            </li>
            <li>
                <a id="Auteur">${auteur}</a>
            </li>
            <li>
                <a class="price" id="prix">${prix}</a>
            </li>
            <li>
                <a id="rabais">${rabais}</a>
            </li>
            <li>
                <a id="description">${description}</a>
            </li>
            <li>
                <a id="niveauScolaire">${niveauScolaire}</a>
            </li>
        </ul>

        <button class="btn ajouter">Ajouter</button>
        <button class="btn supprimer">Supprimer</button>
    </body>

    </div>
</div>
</div>`
}



const livres = [{
        img: "book1.jpg",
        titre: "Ludo Hitoire",
        categorie: "Littérature",
        codeProduit: "1111",
        auteur: "Jean françois",
        prix: "40$",
        rabais: "Rabais : 0%",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        niveauScolaire: "CE1"
    },
    {
        img: "book2.jpg",
        titre: "Mathématique",
        categorie: "Science",
        codeProduit: "2222",
        auteur: "Ali Farah",
        prix: "60$",
        rabais: "Rabais : 0%",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        niveauScolaire: "CE3"
    },

    {
        img: "book3.jpg",
        titre: "Nature",
        categorie: "Science",
        codeProduit: "3333",
        auteur: "Alia Jamil",
        prix: "89$",
        rabais: "Rabais : 0%",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        niveauScolaire: "CE6"
    },

    {
        img: "book4.jpg",
        titre: "Dessin",
        categorie: "Art",
        codeProduit: "4444",
        auteur: "Jean philipe",
        prix: "85$",
        rabais: "Rabais : 0%",
        description: "bLorem ipsum dolor sit amet, consectetur adipiscing elit.",
        niveauScolaire: "CE5"
    },
    {
        img: "book5.jpg",
        titre: "Design",
        categorie: "Art",
        codeProduit: "5555",
        auteur: "Jean philipe",
        prix: "95$",
        rabais: "Rabais : 0%",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        niveauScolaire: "CE5"
    }

]

function montrerLivre(query = '') {
    if (!query){
        return livres;
    }

    const livresFiltrer = livres.filter(({ titre, categorie }) => {
        return (titre === query || categorie === query)
    })

    return livresFiltrer;

}

$(document).ready(function() {
    //avoir la string qui est en haut de la page
    var urlParams = new URLSearchParams(window.location.search);
    const myString = urlParams.get("recherche");
    const livresFiltrer = montrerLivre(myString);
    $('#list-livres').html(livresFiltrer.map(livreTemplate).join(''));
});
