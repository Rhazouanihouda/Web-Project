function validerCode() {
    document.getElementById("affiche").innerHTML = null;
    var bd = new Array();
    bd["login1"] = "pass1";
    bd["login2"] = "pass2";
    bd["login3"] = "pass3";


    var oForm = document.forms["loginForm"];
    var login = oForm.elements["login"].value;
    var pass = oForm.elements["motDePasse"].value;
    if ((login == null) || (login == "")) {
        document.getElementById("affiche").innerHTML = "Encoder un login svp!";
    } else if ((pass == null) || (pass == "")) {
        document.getElementById("affiche").innerHTML = "Encoder un mot de passe svp!";
    } else {
        if (pass == bd[login]) { /*mot de passe correct*/
            return (true);
        } else {
            document.getElementById("affiche").innerHTML = "Mot de passe incorrect!";
        }
    }
    return (false);
}